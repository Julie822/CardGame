package CardGame;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class DealerPanel extends JPanel {
	
	private JLabel label;
	

	public DealerPanel() {
		label = new JLabel("Dealer Panel"); // Example label text
		add(label);

	}
}
