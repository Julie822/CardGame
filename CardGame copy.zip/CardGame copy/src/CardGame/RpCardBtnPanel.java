package CardGame;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;

public class RpCardBtnPanel extends JPanel{
	
	private JLabel label;

	public RpCardBtnPanel() {
		label = new JLabel("RpCardBtnPanel Panel"); // Example label text
		add(label);


	}

}
