package CardGame;

import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;

public class ButtonPanel extends JPanel{
	
	private JLabel label;


	public ButtonPanel() {
		label = new JLabel("ButtonPanel Panel"); // Example label text
		add(label);
	}

}
