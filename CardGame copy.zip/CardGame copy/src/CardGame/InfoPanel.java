package CardGame;

import javax.swing.JLabel;

public class InfoPanel extends MainPanel{
	
	private JLabel label;
	

	public InfoPanel() {
		
	}

}
